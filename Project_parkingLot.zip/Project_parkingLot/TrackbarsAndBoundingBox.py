# Images taken with trone and stiched together
# Detect cars

import cv2
import numpy as np

img = cv2.imread("parking_1.jpg")
#img = cv2.imread("horizontal_img.png")
#img = cv2.imread('cars_30.jpg')
#img = cv2.imread('rotated_complete_lot.jpg')
#img = cv2.resize(img, None, fx=0.2, fy=0.2)
#cv2.imwrite("parking_1.jpg", img2)

def nothing(x):
    pass

cv2.namedWindow("Trackbars")
cv2.resizeWindow('Trackbars', 500, 500)
#cv2.createTrackbar("Threshold", "Trackbars", 70, 255, nothing)
cv2.createTrackbar("Rotation", "Trackbars", 308, 360, nothing)
cv2.createTrackbar("L - H", "Trackbars", 12, 179, nothing)
cv2.createTrackbar("L - S", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("L - V", "Trackbars", 135, 255, nothing)
cv2.createTrackbar("H - H", "Trackbars", 78, 179, nothing)
cv2.createTrackbar("H - S", "Trackbars", 177, 255, nothing)
cv2.createTrackbar("H - V", "Trackbars", 196, 255, nothing)


# gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# print(gray.shape)
# ROI
i = 0
while True:
    i += 1
    #roi = img[8000:9000, 6000: 8000]
    roi = img.copy()
    height, width, _ = roi.shape


    # Rotation of Image

    rot = cv2.getTrackbarPos("Rotation", "Trackbars")
    matrix = cv2.getRotationMatrix2D((width / 2, height / 2), rot, 1)
    roi = cv2.warpAffine(roi, matrix, (height, width))
    cv2.imwrite("image_rotated.jpg", roi)
    #roi = roi[500: 1500, 800: 1500]
    roi = roi[490: 1500, 800: 1500]


    gray_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    gaussian_roi_gray = cv2.GaussianBlur(gray_roi, (5, 5), 0)
    gaussian_roi = cv2.GaussianBlur(roi, (5, 5), 0)
    hsv_roi = cv2.cvtColor(gaussian_roi, cv2.COLOR_BGR2HSV)

    cv2.imwrite("roi_rotated.jpg", roi)


    # Color detection
    """
    Detecting all the cars together by color detection
   """
    l_h = cv2.getTrackbarPos("L - H", "Trackbars")
    l_s = cv2.getTrackbarPos("L - S", "Trackbars")
    l_v = cv2.getTrackbarPos("L - V", "Trackbars")
    h_h = cv2.getTrackbarPos("H - H", "Trackbars")
    h_s = cv2.getTrackbarPos("H - S", "Trackbars")
    h_v = cv2.getTrackbarPos("H - V", "Trackbars")
    low_color = np.array([l_h, l_s, l_v])
    high_color = np.array([h_h, h_s, h_v])
    colorspace_mask = cv2.inRange(hsv_roi, low_color, high_color)
    colorspace_mask_inv = cv2.bitwise_not(colorspace_mask)
    colorspace_roi = cv2.bitwise_and(roi, roi, mask=colorspace_mask)

    ""
    """
    Finding the contours of the cars
    """
    contours, _ = cv2.findContours(colorspace_mask_inv, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)

    # Area of all the cars together
    total_car_area = 0
    for cnt in contours:
        rect = cv2.boundingRect(cnt)
        area = cv2.contourArea(cnt)
        """
        Calculate the area and height of Contours
        We remove it if the height is more than 200
        """
        if area > 1000:
            (x, y, w, h) = rect

            if (h > 200 and w > 170) or (h < 55 and w < 80):
                cv2.rectangle(roi, (x, y), (x + w, y + h), (255, 0, 0), 2)
            else:
                cv2.rectangle(roi, (x, y), (x + w, y + h), (255, 255, 0), 2)
                total_car_area += area
                roi = cv2.drawContours(roi, [cnt], -1, (0, 255, 0), 3)
            # cv2.imshow("Roi", roi)
            # key = cv2.waitKey(0)

    """
    Defin the number of the cars by dividing all the area by a number 900 which we consider to be the size of one car
    """
    cars_number = int(total_car_area / 1200)
    font = cv2.FONT_HERSHEY_PLAIN
    cv2.putText(roi, "Cars: " + str(cars_number), (10, 50), font, 2, (0, 0, 255), 3)


    # Threshold
    # threshold_value = cv2.getTrackbarPos("Threshold", "Trackbars")
    # _, threshold = cv2.threshold(gaussian_roi, threshold_value, 255, cv2.THRESH_BINARY)
    # threshold_inverse = cv2.bitwise_not(threshold)


    # cv2.imshow("Gray", gray)
    #roi = cv2.resize(roi, None, fx=0.5, fy=0.5)
    cv2.imshow("Roi", roi)
    # cv2.imshow("Threshold", threshold)

    cv2.imshow("Colorspace mask inv", colorspace_mask_inv)
    cv2.imshow("Colorspace mask ", colorspace_mask)
    cv2.imshow("Colorspace roi", colorspace_roi)
    # cv2.imshow("Mask", mask)
    key = cv2.waitKey(1)
    if key == 27:
        break

cv2.destroyAllWindows()

#
# kernel = np.ones((5, 5), np.uint8)
# mask = cv2.erode(threshold_inverse, kernel)
#
# # Fid contour
# _, contours, _ = cv2.findContours(threshold, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
#
# for cnt in contours:
#     area = cv2.contourArea(cnt)
#
#     if area > 500:
#         cv2.drawContours(roi, [cnt], -1, (0, 255, 0), thickness=3)
#