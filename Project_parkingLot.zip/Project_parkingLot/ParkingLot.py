
import cv2
import numpy as np
import pandas as pd


img = cv2.imread('test_img.jpg', 1)   #0 for grayscale, 1 for color, -1 for unchanged
#img = cv2.imread('parking_1.jpg', 1)

print(img.shape)

#gray_img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
data = pd.read_csv('pixels.txt', sep=" ", header=None)
data.columns = ["x", "y"]
print(data)

cropped_imgList = []
average_colorList = []

car_count = 0
empty_count = 0
total = 0
n = 1
#print(len(data))

ref_Empty_img = img[data.at[0, 'y']:data.at[1, 'y'], data.at[0, 'x']:data.at[1, 'x']]
ref_img_avg_color_perRow = np.average(ref_Empty_img, axis=0)
ref_avg_color = np.average(ref_img_avg_color_perRow, axis=0)
print('Average color of Reference empty space: ', ref_avg_color)

for i in range(0, len(data), 2):
    crop_img = img[data.at[i, 'y']:data.at[i+1, 'y'], data.at[i, 'x']:data.at[i+1, 'x']]
    cropped_imgList.append(crop_img)

    avg_color_per_row = np.average(crop_img, axis=0)
    avg_color = np.average(avg_color_per_row, axis=0)
    average_colorList.append(avg_color)
    print(n, " Avg Color : ", avg_color)

    #Find the diff
    diff = ref_avg_color - avg_color
    print('difference : ', diff)

    numstr = str(n)

    #if avg_color[0] > 115 and avg_color[1] > 115 and avg_color[2] > 115 and not 405 <= total <= 420:
    if diff[0] < 40 and diff[1] < 48 and diff[2] < 51 :
        empty_count += 1
        cv2.rectangle(img, (data.at[i, 'x'], data.at[i, 'y']), (data.at[i + 1, 'x'], data.at[i + 1, 'y']), (0, 255, 0),
                      2)

        cv2.putText(img, numstr, (data.at[i, 'x'], data.at[i, 'y']), cv2.FONT_HERSHEY_SIMPLEX,
                    0.4, (255, 0, 0), 1)
    else:
        car_count += 1
        cv2.rectangle(img, (data.at[i, 'x'], data.at[i, 'y']), (data.at[i + 1, 'x'],
                                                                data.at[i + 1, 'y']), (0, 0, 255), 2)
        cv2.putText(img, numstr, (data.at[i, 'x'], data.at[i, 'y']), cv2.FONT_HERSHEY_SIMPLEX,
                    0.4, (255, 0, 0), 1)

    total = 0
    n += 1

print('Total number of cars : ', car_count)
print('Total number of empty spaces : ', empty_count)
font = cv2.FONT_HERSHEY_PLAIN
cv2.putText(img, "Total number of cars: " + str(car_count), (10, 20), font, 2, (0, 0, 255), 2)
cv2.imshow('Parking lot', img)
cv2.waitKey(0)
cv2.destroyAllWindows()




