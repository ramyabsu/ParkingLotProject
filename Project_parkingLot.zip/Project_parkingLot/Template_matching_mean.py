import cv2
import numpy as np
from matplotlib import pyplot as plt

class ParkingLotRow(object):
    top_left = None
    bottom_right = None
    roi = None
    col_mean = None
    inverted_variance = None
    empty_spaces = 0
    total_spaces = None

    def __init__(self, top_left, bot_right, num_spaces):
        self.top_left = top_left
        self.bottom_right = bot_right
        self.total_spaces = num_spaces

# TWEAKING PARAMETERS
# test_img
car_width = 16     #in pixels
thresh = 0.945 #0.965      #used to determine if a spot is empty

# img_temp
# car_width = 16     #in pixels
# thresh = 0.935 #0.965      #used to determine if a spot is empty

# -----------------------------------------------------------------------
parking_rows = []

# ROIs

# img_temp
# parking_rows.append(ParkingLotRow((86, 22), (621, 43), 25))     #row 1
# parking_rows.append(ParkingLotRow((83, 64), (621, 84), 25))     #row 2
# parking_rows.append(ParkingLotRow((60, 168), (640, 190), 27))     #row 3
# parking_rows.append(ParkingLotRow((41, 208), (640, 230), 28))     #row 4
# parking_rows.append(ParkingLotRow((20, 309), (663, 330), 30))     #row 5
# parking_rows.append(ParkingLotRow((20, 353), (663, 374), 30))     #row 6

# test_img
parking_rows.append(ParkingLotRow((88, 12), (405, 34), 14))     #row 1
parking_rows.append(ParkingLotRow((88, 53), (405, 73), 14))     #row 2

parking_rows.append(ParkingLotRow((66, 166), (405, 187), 15))     #row 1
parking_rows.append(ParkingLotRow((42, 209), (408, 230), 16))     #row 2
parking_rows.append(ParkingLotRow((20, 319), (588, 341), 25))     #row 3
parking_rows.append(ParkingLotRow((20, 363), (585, 385), 25))     #row 4

parking_rows.append(ParkingLotRow((1, 472), (609, 493), 27))     #row 1
parking_rows.append(ParkingLotRow((1, 518), (609, 538), 27))     #row 2


# read image
#img = cv2.imread('IMG.jpg')
img = cv2.imread('test_img.jpg')
# img = cv2.imread('img_temp.jpg')

# create a template of the empty space
# y1:y2, x1:x2

# img_temp
# template = img[255:275, 150:167]

# test_img
template = img[258:276, 88:101]


m, n, chan = img.shape

# blur the template a bit
template = cv2.GaussianBlur(template, (3, 3), 2)
h, w, chan = template.shape

# Apply template Matching
res = cv2.matchTemplate(img, template, cv2.TM_CCORR_NORMED)
cv2.imshow("res", res)
min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

top_left = max_loc
#print('top_left - ', top_left)

bottom_right = (top_left[0] + w, top_left[1] + h)
# Draw bounding box on template
cv2.rectangle(img, top_left, bottom_right, 255, 2)

# draw bounding box on ROIs
for current_pl_row in parking_rows:
    tl = current_pl_row.top_left
    br = current_pl_row.bottom_right

    cv2.rectangle(res, tl, br, 1, 3)
    cv2.rectangle(img, tl, br, 1, 3)

plt.plot()
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.title('Original image and  template'), plt.xticks([]), plt.yticks([])
# plt.imshow(cv2.cvtColor(res, cv2.COLOR_BGR2RGB))
# plt.title('ROIs after template matching'), plt.xticks([]), plt.yticks([])
plt.show()

# curr_idx = int(0)
curr_idx = 0

# overlay on original image
total_car_count = 0
total_parking_spaces = 0
total_empty_spaces = 0
f0 = plt.figure(4)
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)), plt.title('Original')
plt.imshow(template)

print('Total number of cars and empty spaces in each parking rows:')
print('------------------------------------------------------------')

for current_pl_row in parking_rows:
    # create the ROI
    tl = current_pl_row.top_left
    br = current_pl_row.bottom_right

    my_roi = res[tl[1]:br[1], tl[0]:br[0]]  # y1:y2, x1:x2

    # extract statistics by column
    current_pl_row.col_mean = np.mean(my_roi, 0)
    # print("col mean", curr_parking_lot_row.col_mean)
    current_pl_row.inverted_variance = 1 - np.var(my_roi, 0)

    # plots
    f1 = plt.figure(1)
    a = plt.subplot('81%d' % (curr_idx + 1)), plt.plot(current_pl_row.col_mean), plt.title('Row %d correlation' % (curr_idx + 1))

    f2 = plt.figure(2)
    plt.subplot('81%d' % (curr_idx + 1)), plt.plot(current_pl_row.inverted_variance), plt.title('Row %d variance' % (curr_idx + 1))

    f3 = plt.figure(3)
    plt.subplot('81%d' % (curr_idx + 1))
    plt.plot(current_pl_row.col_mean), plt.title('row %d empty parking space detection' % (curr_idx + 1))
    plt.plot((1, n), (thresh, thresh), c='r')

    # count empty spaces
    pixels_over_thresh = 0
    curr_col = 0

    # for mean_val in curr_parking_lot_row:
    for mean_val in current_pl_row.col_mean:
        curr_col += 1

        if mean_val > thresh:
            pixels_over_thresh += 1
        else:
            pixels_over_thresh = 0

        if pixels_over_thresh >= car_width:
            current_pl_row.empty_spaces += 1

            # add dots to plt
            plt.figure(3)   # the probability graph
            plt.scatter(curr_col, 1, c='g')

            plt.figure(4)   # parking lot image

            # 4 and 9 are used to allign the dots properly in the below line
            plt.scatter(current_pl_row.top_left[0] + curr_col - 4, current_pl_row.top_left[1] + 9, c='g')

            # reset the counter
            pixels_over_thresh = 0

    # set axis range
    plt.figure(3)
    plt.xlim([0, n])


    print('Row {0} : Found {1} cars and {2} empty spaces'.format(
        curr_idx + 1, current_pl_row.total_spaces - current_pl_row.empty_spaces,
        current_pl_row.empty_spaces))
    total_parking_spaces += current_pl_row.total_spaces
    total_empty_spaces += current_pl_row.empty_spaces
    total_car_count = total_parking_spaces - total_empty_spaces
    curr_idx += 1
print('Total number of parking spaces - ', total_parking_spaces)
print('Total empty spaces - ', total_empty_spaces)

print("Total cars in the parking lot - ", total_car_count)
print('------------------------------------------------------------')
print("Actual car count - 124")

# show all the plots
plt.show()