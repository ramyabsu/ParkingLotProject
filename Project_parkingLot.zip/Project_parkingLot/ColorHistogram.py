import cv2
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import math


#Histogram using plt
histList = []
def genarate_hist(image):
    for i, col in enumerate(['b', 'g', 'r']):
        hist = cv2.calcHist([image], [i], None, [255], [0, 255])
        histList.append(hist)
        plt.plot(hist, color=col)
        plt.xlim([0, 256])
    plt.show()

img = cv2.imread('test_img.jpg', 1)
data = pd.read_csv('pixels.txt', sep=" ", header=None)
data.columns = ["x", "y"]
#print(data)

cropped_imgList = []
average_colorList = []
total_avg_color = []
car_count = 0
empty_count = 0
total = 0
total_ref_img = 0
n = 2
#print(len(data))

# draw rectangle for ref image
# find the avg color
ref_Empty_img = img[data.at[0, 'y']:data.at[1, 'y'], data.at[0, 'x']:data.at[1, 'x']]
cv2.rectangle(img, (data.at[0, 'x'], data.at[0, 'y']), (data.at[1, 'x'], data.at[1, 'y']),
                      (0, 255, 0), 2)
cv2.putText(img, '1', (data.at[0, 'x'], data.at[0, 'y']), cv2.FONT_HERSHEY_SIMPLEX,
                    0.4, (255, 0, 0), 1)
ref_img_avg_color_perRow = np.average(ref_Empty_img, axis=0)
ref_avg_color = np.average(ref_img_avg_color_perRow, axis=0)
print('Average color of Reference empty space: ', ref_avg_color)

for i in range(2, len(data), 2):
    crop_img = img[data.at[i, 'y']:data.at[i+1, 'y'], data.at[i, 'x']:data.at[i+1, 'x']]
    cropped_imgList.append(crop_img)

    avg_color_per_row = np.average(crop_img, axis=0)
    avg_color = np.average(avg_color_per_row, axis=0)
    average_colorList.append(avg_color)
    print(n, " Avg Color : ", avg_color)

    numstr = str(n)
    diff = ref_avg_color - avg_color
    print('difference : ', diff)
    total_diff = 0
    for j in diff:
        total_diff += j
    print('Total Difference : ', total_diff)

   #print('max y value : ', max)
    #if -40 < total_diff < 45:
    if diff[0] < 7 and diff[1] < 60 and diff[2] < 14:
        empty_count += 1
        cv2.rectangle(img, (data.at[i, 'x'], data.at[i, 'y']), (data.at[i + 1, 'x'], data.at[i + 1, 'y']),
                      (0, 255, 0), 2)
        cv2.putText(img, numstr, (data.at[i, 'x'], data.at[i, 'y']), cv2.FONT_HERSHEY_SIMPLEX,
                    0.4, (255, 0, 0), 1)
    else:
        car_count += 1
        cv2.rectangle(img, (data.at[i, 'x'], data.at[i, 'y']), (data.at[i + 1, 'x'],
                                                                data.at[i + 1, 'y']), (0, 0, 255), 2)
        cv2.putText(img, numstr, (data.at[i, 'x'], data.at[i, 'y']), cv2.FONT_HERSHEY_SIMPLEX,
                    0.4, (255, 0, 0), 1)

    total = 0
    n += 1

# genarate_hist(cropped_imgList[0]) # empty
# genarate_hist(cropped_imgList[1]) #black car
# genarate_hist(cropped_imgList[6]) # empty(shadow)
# genarate_hist(cropped_imgList[13]) # white car
# genarate_hist(cropped_imgList[49])  # white car
# genarate_hist(cropped_imgList[59])   # blue
#genarate_hist(cropped_imgList[28])


print('Total number of cars : ', car_count)
print('Total number of empty spaces : ', empty_count)
font = cv2.FONT_HERSHEY_PLAIN
cv2.putText(img, "Total number of cars: " + str(car_count), (10, 20), font, 2, (0, 0, 255), 2)
cv2.imshow('Parking lot', img)
cv2.waitKey(0)
cv2.destroyAllWindows()